/* Kalkulator Teknik UBS — antarmuka */
(function () {
  'use strict';
  var KT = window.KT;
  var P = KT.parseNum;
  var VER = '2.0.0';
  var LS = 'ktubs2_';

  /* ---------- Penyimpanan aman ---------- */
  function lsGet(k, d) { try { var v = localStorage.getItem(LS + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(LS + k, JSON.stringify(v)); } catch (e) { } }

  /* ---------- Format angka (id-ID) ---------- */
  function f(n, dec) {
    if (n === null || n === undefined || !isFinite(n)) return '–';
    dec = dec === undefined ? 0 : dec;
    return Number(n).toLocaleString('id-ID', { minimumFractionDigits: dec, maximumFractionDigits: dec });
  }
  function fs(n) { // jumlah digit menyesuaikan besar angka
    if (!isFinite(n)) return '–';
    var a = Math.abs(n);
    var d = a >= 1000 ? 1 : a >= 100 ? 2 : a >= 1 ? 3 : 4;
    return Number(n).toLocaleString('id-ID', { maximumFractionDigits: d });
  }
  function pct(x, dec) { return f(x * 100, dec === undefined ? 1 : dec) + '%'; }
  function fin(n, dec) { // untuk ditulis kembali ke isian: tanpa pemisah ribuan, desimal koma
    var m = Math.pow(10, dec); var r = Math.round(n * m) / m;
    return String(r).replace('.', ',');
  }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function jamTx(h) {
    if (!isFinite(h)) return '–';
    var tot = Math.round(h * 60), j = Math.floor(tot / 60), m = tot % 60;
    return j > 0 ? j + ' jam ' + m + ' mnt' : m + ' mnt';
  }

  /* ---------- Data ---------- */
  var MESIN = {
    'UBS3': ['BLOW1', 'CM1'].concat(rng('PK', 8, 20), rng('PK', 22, 26), rng('PK', 28, 32)),
    'UBS1': ['HC2'].concat(rng('BT', 7, 21), ['CF22', 'DM23', 'DM24', 'BT25', 'DM26', 'DM27', 'HMD28', 'PK21', 'PK27', 'KTX33', 'PK34', 'PK35'])
  };
  function rng(p, a, b) { var r = []; for (var i = a; i <= b; i++) r.push(p + i); return r; }

  var MAT = {
    IMM: {
      HDPE: { b: '190°C – 230°C', m: '20°C – 40°C', n: 'Waspada melengkung (warpage).' },
      PP: { b: '210°C – 260°C', m: '30°C – 50°C', n: 'Alir tinggi; rawan flash.' },
      PET: { b: '270°C – 290°C', m: '10°C – 20°C', n: 'Wajib dikeringkan; getas bila lembap.' },
      ABS: { b: '220°C – 250°C', m: '40°C – 80°C', n: 'Rentan silver streak; keringkan.' },
      PVC: { b: '170°C – 190°C', m: '20°C – 40°C', n: 'Sensitif panas; jangan dibiarkan idle di barel.' }
    },
    EBM: {
      HDPE: { b: '160°C – 190°C', m: '180°C – 190°C', n: 'Suhu berlebih membuat parison melorot.' },
      PP: { b: '180°C – 210°C', m: '190°C – 210°C', n: 'Rentan sobek saat ditiup.' },
      PET: { b: '250°C – 275°C', m: '260°C', n: 'Umumnya diproses ISBM, bukan EBM.' },
      ABS: { b: '190°C – 210°C', m: '200°C', n: 'Butuh screw khusus anti-degradasi.' },
      PVC: { b: '160°C – 180°C', m: '175°C', n: 'Butuh die head berlapis krom (anti-korosi).' }
    }
  };
  var GRADE = {
    IMM: [
      ['Trilene BI5.0GN', 'PP', '220°C – 240°C (melt)', 'TDS Trilene / Chandra Asri'],
      ['Titanvene HD5218EA', 'HDPE', '200°C – 240°C', 'TDS Titan Petrokimia Nusantara'],
      ['InnoPlus HD1010J', 'HDPE', '190°C – 230°C', 'TDS GC InnoPlus'],
      ['InnoPlus HD1100J', 'HDPE', 'Rear/Mid 165–190°C · Nozzle 180–195°C', 'IDES Prospector / PTT Chemical'],
      ['Trilene BI5.0GA', 'PP', null, 'Material Data Center (Trilene / Chandra Asri)'],
      ['Topilene J640N', 'PP', null, 'TDS Hyosung Vina Chemicals']
    ],
    EBM: [
      ['Marlex HXM 50100', 'HDPE', null, 'TDS Marlex (Chevron Phillips)'],
      ['Titanvene HD5401GA', 'HDPE', null, 'TDS Titan Petrokimia Nusantara'],
      ['InnoPlus HD6600B', 'HDPE', null, 'TDS GC InnoPlus']
    ]
  };

  var TROUBLE = {
    IMM: [
      ['flash', 'Flash / Sayap', 'Flash (sayap) pada parting line', [
        'Bersihkan parting line dari sisa plastik/kotoran; pastikan mold menutup rapat.',
        'Pastikan tonase clamp mencukupi (cek di tab Tonase) dan clamp mencapai posisi kunci penuh.',
        'Majukan titik V/P switchover lebih awal; turunkan speed injeksi tahap akhir.',
        'Turunkan holding pressure bila flash muncul saat fase holding.',
        'Turunkan suhu leleh bila material terlalu encer.',
        'Bila parting line/insert aus atau penyok → laporkan ke WS.']],
      ['short', 'Short Shot', 'Short shot (produk tidak penuh)', [
        'Periksa hopper/dryer: material habis atau tersumbat.',
        'Cek cushion: bila cushion habis (0) → tambah stroke dosing. Bila cushion masih ada → naikkan speed/pressure injeksi.',
        'Cek suhu aktual tiap zona barel & hot runner; heater atau termokopel mati membuat leleh dingin.',
        'Cek nozzle dan gate tersumbat; bersihkan venting yang tertutup.',
        'Cushion terus turun saat holding → indikasi check ring aus.']],
      ['sink', 'Sink Mark', 'Sink mark (penyok pada dinding tebal)', [
        'Naikkan holding pressure dan perpanjang waktu holding selama gate belum membeku.',
        'Pastikan cushion tidak habis di akhir holding; bila habis tambah dosing atau cek check ring.',
        'Bila suhu leleh atau suhu mold terlalu tinggi, turunkan bertahap (suhu tinggi memperbesar susut).',
        'Tambah cooling time.',
        'Periksa saluran pendingin mold di area sink: tersumbat, selang tertekuk, atau aliran chiller lemah.']],
      ['silver', 'Silver Streak', 'Silver streak (garis perak)', [
        'Pastikan material dikeringkan sesuai suhu dan waktu dryer; cek hopper tertutup.',
        'Turunkan suhu leleh bila terlalu tinggi (degradasi menghasilkan gas).',
        'Naikkan back pressure sedikit agar udara terdorong keluar saat dosing.',
        'Kurangi suck back/decompression yang berlebihan.',
        'Mold berembun (suhu mold di bawah titik embun) → naikkan suhu air mold.']],
      ['warp', 'Warpage', 'Warpage (produk melengkung)', [
        'Seimbangkan suhu core dan cavity; cek aliran pendingin kedua sisi sama.',
        'Tambah cooling time.',
        'Atur holding: terlalu tinggi menimbulkan tegangan sisa, terlalu rendah menimbulkan susut tidak rata.',
        'Pastikan ejector mendorong rata dan tidak terlalu cepat.',
        'Atur cara penumpukan produk yang masih panas.']],
      ['burn', 'Burn Mark', 'Burn mark (gosong di ujung aliran)', [
        'Bersihkan venting mold; udara terjebak terbakar (efek diesel).',
        'Turunkan speed injeksi tahap akhir pengisian.',
        'Turunkan suhu leleh atau kurangi waktu tinggal material di barel.',
        'Kurangi RPM screw/back pressure bila gesekan berlebihan.']],
      ['weld', 'Weld Line', 'Weld line / flow line', [
        'Naikkan speed injeksi agar aliran bertemu dalam keadaan panas.',
        'Naikkan suhu leleh dan/atau suhu mold secara bertahap.',
        'Bersihkan venting di area pertemuan aliran.',
        'Bila garis selalu di titik yang sama dan tidak hilang → laporkan ke WS (desain gate/venting).']]
    ],
    EBM: [
      ['sag', 'Parison Melorot', 'Parison melorot (sagging): atas tipis, bawah tebal', [
        'Turunkan suhu die head dan zona barel akhir secara bertahap.',
        'Percepat pembentukan parison (naikkan output/RPM screw) agar waktu menggantung lebih singkat.',
        'Koreksi program ketebalan parison (wall thickness profile) di titik yang tipis.',
        'Cek material: MFI terlalu tinggi atau campuran regrind berlebih menurunkan kekuatan leleh.']],
      ['uneven', 'Tebal Tidak Rata', 'Tebal dinding tidak rata keliling (satu sisi tipis)', [
        'Cek centering die: atur baut centering agar celah die rata keliling.',
        'Cek suhu aktual tiap zona die head; satu heater mati membuat sisi tersebut tebal/tipis.',
        'Periksa die pin/mandrel: kotor, tergores, atau ukuran tertukar.',
        'Pastikan parison jatuh lurus, tidak terkena angin atau menyentuh komponen.']],
      ['pinch', 'Pinch-off Lemah', 'Pinch-off lemah / bocor di dasar', [
        'Cek bibir pinch-off pada mold: tumpul, aus, atau gompal → laporkan ke WS.',
        'Pastikan clamp menutup penuh dan tekanan clamp cukup.',
        'Parison terlalu dingin di area bawah → naikkan sedikit suhu atau percepat siklus.',
        'Atur pre-blow dan tunda tiup (blow delay) agar pinch-off sempat terbentuk.',
        'Tambah ketebalan parison di area pinch-off lewat program parison.']],
      ['blowout', 'Blow-out', 'Blow-out (meletus saat ditiup)', [
        'Cek parison berlubang atau ada titik tipis (kontaminasi, degradasi, kotoran di die).',
        'Turunkan tekanan tiup atau mulai tiup sedikit lebih lambat.',
        'Pastikan mold menutup rapat dan pinch-off menjepit sempurna.',
        'Cek blow pin dan seal-nya: bocor atau posisi tidak center.']],
      ['neck', 'Flash Leher', 'Flash / cacat di leher', [
        'Cek cutting sleeve dan blow pin: aus atau tumpul → ganti/laporkan ke WS.',
        'Pastikan posisi blow pin center terhadap leher mold.',
        'Parison terlalu lebar di area leher → koreksi program parison atau ukuran die.',
        'Cek langkah dan tekanan calibrating/kalibrasi leher.']],
      ['dieline', 'Garis Memanjang', 'Garis memanjang (die line)', [
        'Bersihkan die head; kotoran atau material gosong menempel di bibir die.',
        'Periksa bibir die dan die pin tergores → laporkan ke WS bila rusak.',
        'Cek material: kontaminasi atau gel dari regrind.']],
      ['black', 'Bintik Hitam', 'Bintik hitam (black specks)', [
        'Lakukan purging; material terdegradasi di barel/die head.',
        'Cek zona suhu yang terlalu panas (overheat) dan termokopel.',
        'Material yang lama berhenti di head (saat mesin idle) → buang beberapa siklus awal.',
        'Cek kebersihan regrind, hopper, dan karung material.']],
      ['shrink', 'Bentuk Berubah', 'Produk berubah bentuk / dasar menggembung (rocker bottom)', [
        'Tambah waktu tiup/pendinginan di dalam mold.',
        'Cek suhu dan aliran air chiller ke mold.',
        'Pastikan tekanan tiup cukup sampai produk menempel penuh ke dinding mold.',
        'Pembuangan udara (exhaust) jangan terlalu cepat.']]
    ]
  };

  var COOL_MAT = {
    HDPE: { alpha: '0,11', tm: '220', tw: '30', te: '85' },
    PP: { alpha: '0,09', tm: '230', tw: '40', te: '95' },
    ABS: { alpha: '0,10', tm: '240', tw: '60', te: '85' },
    PS: { alpha: '0,09', tm: '220', tw: '40', te: '80' },
    PC: { alpha: '0,12', tm: '290', tw: '85', te: '125' }
  };

  var LINK_STANDAR = 'https://standar-setting-ubs.pages.dev/';
  var LINK_HUB = 'https://hub-mekanik-ubs.pages.dev/';

  /* ---------- Pembentuk isian ---------- */
  function num(k, label, o) {
    o = o || {};
    var id = 'f_' + k + '_' + (num.n = (num.n || 0) + 1);
    var st = o.step ? '<button type="button" class="st" data-step="-' + o.step + '" aria-label="Kurangi">−</button>' : '';
    var st2 = o.step ? '<button type="button" class="st" data-step="' + o.step + '" aria-label="Tambah">+</button>' : '';
    var q = '';
    if (o.quick) q = '<div class="quick">' + o.quick.map(function (x) { return '<button type="button" data-set="' + k + '" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>';
    return '<div class="fld"' + show(o.show) + '><label for="' + id + '">' + label + (o.unit ? ' <span class="u">(' + o.unit + ')</span>' : '') + '</label>' +
      '<div class="num">' + st + '<input id="' + id + '" data-k="' + k + '"' + (o.int ? ' data-int="1" inputmode="numeric"' : ' inputmode="decimal"') +
      ' autocomplete="off" enterkeyhint="done" placeholder="' + (o.ph || '') + '"' + (o.min !== undefined ? ' data-min="' + o.min + '"' : '') +
      (o.dec !== undefined ? ' data-dec="' + o.dec + '"' : '') + '>' + st2 + '</div>' + q +
      (o.hint ? '<span class="hint">' + o.hint + '</span>' : '') + '</div>';
  }
  function txt(k, label, o) {
    o = o || {};
    var id = 'f_' + k + '_' + (num.n = (num.n || 0) + 1);
    return '<div class="fld"' + show(o.show) + '><label for="' + id + '">' + label + '</label><input class="txt" id="' + id + '" data-k="' + k + '" data-txt="1"' +
      (o.list ? ' list="' + o.list + '" autocapitalize="characters"' : '') + ' autocomplete="off" enterkeyhint="done" placeholder="' + (o.ph || '') + '"></div>';
  }
  function chips(k, label, opts, o) {
    o = o || {};
    return '<div class="fld"' + show(o.show) + '>' + (label ? '<span class="lbl">' + label + '</span>' : '') +
      '<div class="' + (o.seg ? 'seg' : 'chips') + '" data-ck="' + k + '">' +
      opts.map(function (x) { return '<button type="button" data-v="' + esc(x[0]) + '">' + x[1] + '</button>'; }).join('') + '</div></div>';
  }
  function show(s) { return s ? ' data-show="' + s + '"' : ''; }
  function presetRow() {
    return '<div class="presetRow"><select data-preset="1" aria-label="Pilih preset mesin"></select>' +
      '<button type="button" class="btn ghost" data-act="savePreset">Simpan</button></div>' +
      txt('mesin', 'Mesin', { list: 'dlMesin', ph: 'mis. PK12 (opsional)' });
  }

  /* ---------- Pembentuk hasil ---------- */
  function rowsHtml(rows) {
    return '<table class="rows">' + rows.map(function (r) {
      if (r.sep) return '<tr class="sep"><td colspan="2">' + r.sep + '</td></tr>';
      return '<tr' + (r[2] ? ' class="strong"' : '') + '><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>';
    }).join('') + '</table>';
  }
  function notesHtml(n, w) {
    if ((!n || !n.length) && (!w || !w.length)) return '';
    return '<ul class="notes">' + (w || []).map(function (x) { return '<li class="w">' + x + '</li>'; }).join('') +
      (n || []).map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>';
  }
  function mesinTx(v) { return v.mesin ? ' (' + v.mesin + ')' : ''; }

  /* =====================================================================
     DEFINISI ALAT
     ===================================================================== */
  var GROUPS = [
    ['produksi', 'Produksi', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 20h18M5 20V10l5 3V10l5 3V6h4v14"/></svg>'],
    ['listrik', 'Listrik', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg>'],
    ['proses', 'Proses', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M10 3v6.5L4.5 19a1.5 1.5 0 0 0 1.3 2h12.4a1.5 1.5 0 0 0 1.3-2L14 9.5V3M8.5 3h7M7 15h10"/></svg>'],
    ['bengkel', 'Bengkel', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/></svg>']
  ];

  var TOOLS = [];
  function T(o) { TOOLS.push(o); return o; }

  /* ---- 1. Output & OEE ---- */
  T({
    id: 'output', g: 'produksi', name: 'Output & OEE', preset: true,
    def: { mesin: '', jam: '8', ct: '12', cav: '1', down: '0', aktual: '', rej: '0', rejMode: 'pct' },
    form: function () {
      return presetRow() +
        num('jam', 'Durasi tersedia', { unit: 'jam', step: 1, min: 0.5, quick: [['8', '1 shift'], ['24', '1 hari'], ['168', '1 minggu'], ['720', '30 hari']] }) +
        '<div class="row2">' + num('ct', 'Cycle time', { unit: 'detik', step: 0.5, min: 0.5 }) + num('cav', 'Cavity', { int: 1, step: 1, min: 1 }) + '</div>' +
        num('down', 'Total downtime dalam durasi itu', { unit: 'menit', step: 5, min: 0 }) +
        num('aktual', 'Output aktual', { unit: 'pcs', int: 1, ph: 'kosongkan bila belum ada', hint: 'Bila diisi, Performance dihitung dari data nyata (OEE sebenarnya).' }) +
        chips('rejMode', 'Satuan reject', [['pct', 'Persen (%)'], ['pcs', 'Jumlah (pcs)']], { seg: 1 }) +
        num('rej', 'Reject', { step: 1, min: 0 });
    },
    calc: function (v) {
      var r = KT.output({ jam: P(v.jam), ct: P(v.ct), cav: P(v.cav, 1), down: P(v.down), aktual: P(v.aktual, 1), rej: P(v.rej, v.rejMode === 'pcs'), rejMode: v.rejMode });
      if (r.err) return r;
      var head = r.estimasi
        ? { lbl: 'Estimasi produk bagus' + mesinTx(v), val: f(r.good) + ' pcs', sub: 'OEE estimasi ' + pct(r.oee) + ' · Performance dianggap 100%' }
        : { lbl: 'OEE' + mesinTx(v), val: pct(r.oee), sub: 'A ' + pct(r.A) + ' · P ' + pct(r.P) + ' · Q ' + pct(r.Q), st: r.P > 1.0001 ? 'warn' : r.oee >= 0.85 ? 'ok' : r.oee >= 0.6 ? 'warn' : 'bad' };
      var rows = [
        { sep: 'Waktu' }, ['Durasi tersedia', f(P(v.jam), 1) + ' jam'], ['Downtime', f(r.down) + ' mnt'], ['Waktu jalan', jamTx(r.run / 60)],
        { sep: 'Output' }, ['RAW 100% jalan (tanpa downtime)', f(r.raw) + ' pcs'], ['Potensi setelah downtime', f(r.potensi) + ' pcs'],
        [r.estimasi ? 'Total (estimasi)' : 'Total aktual', f(r.total) + ' pcs'], ['Reject', f(r.rej) + ' pcs'], ['Produk bagus', f(r.good) + ' pcs', 1],
        ['Kapasitas ideal per jam', f(r.perJam) + ' pcs'],
        { sep: 'OEE' }, ['Availability', pct(r.A)], ['Performance', r.estimasi ? '100% (asumsi)' : pct(r.P)], ['Quality', pct(r.Q)], ['OEE', pct(r.oee), 1]
      ];
      var share = 'OUTPUT & OEE' + mesinTx(v) + '\nCT ' + v.ct + ' dtk · ' + v.cav + ' cav · ' + f(P(v.jam), 1) + ' jam · downtime ' + f(r.down) + ' mnt\n' +
        'Total ' + f(r.total) + ' pcs · Reject ' + f(r.rej) + ' · Bagus ' + f(r.good) + ' pcs\n' +
        'A ' + pct(r.A) + ' · P ' + (r.estimasi ? '100% (asumsi)' : pct(r.P)) + ' · Q ' + pct(r.Q) + ' → OEE ' + pct(r.oee);
      return { head: head, body: rowsHtml(rows) + notesHtml(['OEE = Availability × Performance × Quality. Acuan kelas dunia ±85%.'], r.warn), share: share };
    }
  });

  /* ---- 2. Kalkulator Target ---- */
  T({
    id: 'target', g: 'produksi', name: 'Target', preset: true,
    def: { mesin: '', qty: '10000', ct: '12', cav: '1', eff: '85', jamShift: '8' },
    form: function () {
      return presetRow() + num('qty', 'Target produksi', { unit: 'pcs', int: 1, step: 1000, min: 1 }) +
        '<div class="row2">' + num('ct', 'Cycle time', { unit: 'detik', step: 0.5, min: 0.5 }) + num('cav', 'Cavity', { int: 1, step: 1, min: 1 }) + '</div>' +
        num('eff', 'Efisiensi realistis', { unit: '%', step: 5, min: 1, hint: 'Memperhitungkan downtime & reject. Gunakan nilai OEE mesin bila ada.' }) +
        num('jamShift', 'Jam kerja per shift', { unit: 'jam', step: 1, min: 1 });
    },
    calc: function (v) {
      var r = KT.target({ qty: P(v.qty, 1), ct: P(v.ct), cav: P(v.cav, 1), eff: P(v.eff), jamShift: P(v.jamShift) });
      if (r.err) return r;
      var rows = [['Jumlah shot', f(r.shots)], ['Waktu bersih (100% jalan)', jamTx(r.jamBersih)], ['Waktu realistis (efisiensi ' + f(r.eff) + '%)', jamTx(r.jamNyata), 1],
        ['Setara shift (' + f(r.jamShift, 1) + ' jam)', f(r.shift, 1) + ' shift'], ['Setara hari (24 jam)', f(r.hari, 1) + ' hari'],
        ['Output ideal per jam', f(r.perJamIdeal) + ' pcs'], ['Output realistis per jam', f(r.perJamNyata) + ' pcs']];
      return {
        head: { lbl: 'Waktu yang dibutuhkan' + mesinTx(v), val: jamTx(r.jamNyata), sub: '≈ ' + f(r.shift, 1) + ' shift · ' + f(r.hari, 1) + ' hari (24 jam)' },
        body: rowsHtml(rows),
        share: 'TARGET PRODUKSI' + mesinTx(v) + '\nTarget ' + f(P(v.qty, 1)) + ' pcs · CT ' + v.ct + ' dtk · ' + v.cav + ' cav · efisiensi ' + f(r.eff) + '%\n' +
          'Waktu: ' + jamTx(r.jamNyata) + ' (≈ ' + f(r.shift, 1) + ' shift / ' + f(r.hari, 1) + ' hari)'
      };
    }
  });

  /* ---- 3. Kerugian Downtime ---- */
  T({
    id: 'downtime', g: 'produksi', name: 'Kerugian Downtime', preset: true,
    def: { mesin: '', menit: '60', ct: '12', cav: '1', harga: '' },
    form: function () {
      return presetRow() + num('menit', 'Lama mesin mati', { unit: 'menit', step: 15, min: 1, quick: [['30', '30 mnt'], ['60', '1 jam'], ['120', '2 jam'], ['480', '1 shift']] }) +
        '<div class="row2">' + num('ct', 'Cycle time', { unit: 'detik', step: 0.5, min: 0.5 }) + num('cav', 'Cavity', { int: 1, step: 1, min: 1 }) + '</div>' +
        num('harga', 'Nilai per pcs', { unit: 'Rp', int: 1, ph: 'opsional' });
    },
    calc: function (v) {
      var r = KT.downtime({ menit: P(v.menit), ct: P(v.ct), cav: P(v.cav, 1), harga: P(v.harga, 1) });
      if (r.err) return r;
      var rows = [['Lama mati', jamTx(P(v.menit) / 60)], ['Shot hilang', f(r.shots)], ['Output hilang', f(r.pcs) + ' pcs', 1], ['Kapasitas mesin per jam', f(r.perJam) + ' pcs']];
      if (r.rupiah !== null) rows.push(['Nilai output hilang', 'Rp ' + f(r.rupiah), 1]);
      var share = 'KERUGIAN DOWNTIME' + mesinTx(v) + '\nMati ' + jamTx(P(v.menit) / 60) + ' (CT ' + v.ct + ' dtk · ' + v.cav + ' cav)\n' +
        'Output hilang: ' + f(r.pcs) + ' pcs' + (r.rupiah !== null ? ' (± Rp ' + f(r.rupiah) + ')' : '');
      return {
        head: { lbl: 'Output hilang' + mesinTx(v), val: f(r.pcs) + ' pcs', sub: f(r.shots) + ' shot' + (r.rupiah !== null ? ' · ± Rp ' + f(r.rupiah) : ''), st: 'bad' },
        body: rowsHtml(rows) + notesHtml(['Angka ini adalah kehilangan kapasitas teoretis pada CT standar. Cocok untuk laporan dampak kerusakan ke atasan.']),
        share: share
      };
    }
  });

  /* ---- 4. Preset Mesin ---- */
  T({
    id: 'preset', g: 'produksi', name: 'Preset Mesin', noShare: true,
    def: { pMesin: '', pMould: '', pCt: '', pCav: '' },
    form: function () {
      return txt('pMesin', 'Mesin', { list: 'dlMesin', ph: 'mis. PK12' }) + txt('pMould', 'Mould / produk', { ph: 'opsional, mis. Botol 1L' }) +
        '<div class="row2">' + num('pCt', 'Cycle time', { unit: 'detik', step: 0.5, min: 0.5 }) + num('pCav', 'Cavity', { int: 1, step: 1, min: 1 }) + '</div>' +
        '<div class="fld"><button type="button" class="btn" style="width:100%" data-act="addPreset">Tambah Preset</button></div>';
    },
    calc: function () {
      var L = presets();
      var body = L.length ? L.map(function (p) {
        return '<div class="pItem"><div><b>' + esc(p.mesin) + (p.mould ? ' · ' + esc(p.mould) : '') + '</b><small>CT ' + esc(p.ct) + ' dtk · ' + esc(p.cav) + ' cavity</small></div>' +
          '<button type="button" class="del" data-act="delPreset" data-id="' + esc(p.id) + '">Hapus</button></div>';
      }).join('') : '<div class="empty">Belum ada preset. Tambahkan di sini, atau tekan "Simpan" pada alat Output/Target/Downtime.</div>';
      return { head: { lbl: 'Preset tersimpan di ponsel ini', val: L.length + ' preset', sub: 'Dipakai di Output & OEE, Target, dan Kerugian Downtime' }, body: body + notesHtml(['Preset tersimpan di perangkat ini saja (tidak terkirim ke server).']) };
    }
  });

  /* ---- 5. Cek Heater ---- */
  T({
    id: 'heater', g: 'listrik', name: 'Cek Heater',
    def: { watt: '', volt: '220', ohm: '' },
    form: function () {
      return num('watt', 'Daya nameplate heater', { unit: 'W', int: 1, step: 100, min: 0, ph: 'mis. 1500' }) +
        num('volt', 'Tegangan nameplate', { unit: 'V', int: 1, quick: [['220', '220 V'], ['380', '380 V']] }) +
        num('ohm', 'Ohm terukur', { unit: 'Ω', step: 0.5, min: 0, ph: 'hasil ukur multimeter', hint: 'Isi daya saja → Ohm seharusnya. Isi Ohm saja → daya aktual. Isi keduanya → kesimpulan kondisi heater.' });
    },
    calc: function (v) {
      var r = KT.heater({ watt: P(v.watt, 1), volt: P(v.volt, 1), ohm: P(v.ohm) });
      if (r.err) return r;
      var head, rows = [];
      if (r.hasW && r.hasR) head = { lbl: 'Kondisi heater', val: r.verdict, sub: 'Selisih ' + (r.dev > 0 ? '+' : '') + f(r.dev, 1) + '% dari seharusnya', st: r.status };
      else if (r.hasW) head = { lbl: 'Ohm seharusnya', val: f(r.rNom, 1) + ' Ω', sub: 'Normal ' + f(r.rNom * 0.9, 1) + ' – ' + f(r.rNom * 1.1, 1) + ' Ω (±10%)' };
      else head = { lbl: 'Daya aktual heater', val: f(r.pAkt) + ' W', sub: f(r.iAkt, 2) + ' A pada ' + r.volt + ' V' };
      if (r.hasW) { rows.push({ sep: 'Menurut nameplate' }, ['Ohm seharusnya', f(r.rNom, 1) + ' Ω'], ['Batas normal ±10%', f(r.rNom * 0.9, 1) + ' – ' + f(r.rNom * 1.1, 1) + ' Ω'], ['Arus nominal', f(r.iNom, 2) + ' A']); }
      if (r.hasR) { rows.push({ sep: 'Menurut hasil ukur' }, ['Ohm terukur', f(P(v.ohm), 1) + ' Ω'], ['Daya aktual', f(r.pAkt) + ' W', 1], ['Arus aktual', f(r.iAkt, 2) + ' A']); }
      var notes = [];
      if (r.why) notes.push(r.why);
      var w = r.hint ? [r.hint] : [];
      notes.push('Ukur dalam keadaan dingin dan kabel heater dilepas dari terminal.', 'Multimeter menunjukkan "OL"/tak terhingga = elemen putus.', 'Cek juga isolasi: Ohm antara terminal dan bodi heater harus sangat besar (≥ 1 MΩ dengan megger 500 V).');
      var share = 'CEK HEATER\n' + (r.hasW ? 'Nameplate ' + f(P(v.watt, 1)) + ' W / ' + r.volt + ' V → seharusnya ' + f(r.rNom, 1) + ' Ω\n' : '') +
        (r.hasR ? 'Terukur ' + f(P(v.ohm), 1) + ' Ω → ' + f(r.pAkt) + ' W\n' : '') + (r.verdict ? 'Kondisi: ' + r.verdict + ' (' + (r.dev > 0 ? '+' : '') + f(r.dev, 1) + '%)' : '');
      return { head: head, body: rowsHtml(rows) + notesHtml(notes, w), share: share.trim() };
    }
  });

  /* ---- 6. SSR ---- */
  T({
    id: 'ssr', g: 'listrik', name: 'SSR',
    def: { watt: '3000', volt: '220', suhu: '40' },
    form: function () {
      return num('watt', 'Total daya heater pada satu SSR', { unit: 'W', int: 1, step: 500, min: 0, quick: [['1000', '1 kW'], ['2000', '2 kW'], ['3000', '3 kW'], ['4500', '4,5 kW'], ['6000', '6 kW']] }) +
        num('volt', 'Tegangan beban', { unit: 'V', int: 1, quick: [['220', '220 V'], ['380', '380 V']] }) +
        num('suhu', 'Suhu dalam panel', { unit: '°C', int: 1, step: 5, min: 20, hint: 'Di atas 40°C kapasitas SSR turun (derating).' });
    },
    calc: function (v) {
      var r = KT.ssr({ watt: P(v.watt, 1), volt: P(v.volt, 1), suhu: P(v.suhu, 1) });
      if (r.err) return r;
      var rows = [['Arus beban', f(r.amp, 1) + ' A'], ['Faktor suhu panel', '×' + f(r.derate, 2)], ['Rating minimal (×1,5)', f(r.minA, 1) + ' A'],
        ['Rating disarankan (×2)', f(r.recA, 1) + ' A', 1], ['Ukuran SSR di pasaran', r.pick ? r.pick + ' A' : '> 120 A'], ['Rating tegangan SSR', r.vRating]];
      var notes = ['Pilih SSR tipe zero-cross untuk heater; input kontrol sesuai output kontroler (umumnya 3–32 VDC).'];
      if (r.heatsink) notes.push('SSR ≥ 25 A wajib heatsink + pasta termal; pastikan sirkulasi udara panel baik.');
      if (P(v.volt, 1) > 250) notes.push('Beban 380 V (antar-fase): SSR memutus satu jalur, heater tetap bertegangan dari fase lain. Matikan MCB sebelum menyentuh heater.');
      var w = r.pick === null ? ['Arus terlalu besar untuk satu SSR; bagi beban ke beberapa SSR atau pakai kontaktor.'] : [];
      return {
        head: { lbl: 'SSR disarankan', val: r.pick ? r.pick + ' A' : '> 120 A', sub: 'Arus beban ' + f(r.amp, 1) + ' A · minimal ' + f(r.minA, 1) + ' A', st: r.pick ? '' : 'bad' },
        body: rowsHtml(rows) + notesHtml(notes, w),
        share: 'SPESIFIKASI SSR\nBeban ' + f(P(v.watt, 1)) + ' W / ' + v.volt + ' V → ' + f(r.amp, 1) + ' A (panel ' + r.suhu + '°C)\nSSR disarankan: ' + (r.pick ? r.pick + ' A' : '> 120 A') + ', ' + r.vRating
      };
    }
  });

  /* ---- 7. Suhu Material ---- */
  T({
    id: 'suhu', g: 'proses', name: 'Suhu Material', noShareIfErr: true,
    def: { proc: 'IMM', ref: 'generic', mat: 'HDPE', gIMM: GRADE.IMM[0][0], gEBM: GRADE.EBM[0][0] },
    form: function () {
      return chips('proc', 'Proses', [['IMM', 'IMM (Injeksi)'], ['EBM', 'EBM (Blow)']], { seg: 1 }) +
        chips('ref', 'Acuan', [['generic', 'Acuan umum'], ['grade', 'Grade spesifik (TDS)']], { seg: 1 }) +
        chips('mat', 'Material', [['HDPE', 'HDPE'], ['PP', 'PP'], ['PET', 'PET'], ['ABS', 'ABS'], ['PVC', 'PVC']], { show: 'ref:generic' }) +
        chips('gIMM', 'Grade', GRADE.IMM.map(function (g) { return [g[0], g[0]]; }), { show: 'ref:grade;proc:IMM' }) +
        chips('gEBM', 'Grade', GRADE.EBM.map(function (g) { return [g[0], g[0]]; }), { show: 'ref:grade;proc:EBM' }) +
        '<a class="linkBtn" href="' + LINK_STANDAR + '" target="_blank" rel="noopener">Buka Standar Setting Parameter ↗</a>';
    },
    calc: function (v) {
      var proc = v.proc, mLbl = proc === 'IMM' ? 'Suhu mold' : 'Suhu die head';
      var notes = ['Ini acuan awal. Bila mesin sudah punya Standar Setting Parameter, standar itulah yang berlaku.'];
      if (v.ref === 'generic') {
        var d = MAT[proc][v.mat];
        return {
          head: { lbl: 'Suhu barel · ' + v.mat + ' · ' + proc, val: d.b, sub: mLbl + ': ' + d.m },
          body: rowsHtml([['Suhu barel', d.b], [mLbl, d.m]]) + notesHtml([d.n].concat(notes)),
          share: 'SUHU MATERIAL ' + v.mat + ' (' + proc + ')\nBarel ' + d.b + ' · ' + mLbl + ' ' + d.m
        };
      }
      var gname = proc === 'IMM' ? v.gIMM : v.gEBM;
      var g = GRADE[proc].filter(function (x) { return x[0] === gname; })[0] || GRADE[proc][0];
      if (g[2]) {
        return {
          head: { lbl: g[0] + ' · ' + g[1], val: g[2], sub: 'Sumber: ' + g[3] },
          body: rowsHtml([['Grade', g[0]], ['Material', g[1]], ['Suhu proses', g[2]], ['Sumber', g[3]]]) + notesHtml(notes),
          share: 'SUHU GRADE ' + g[0] + ' (' + g[1] + ', ' + proc + ')\nSuhu proses ' + g[2] + '\nSumber: ' + g[3]
        };
      }
      var gd = MAT[proc][g[1]];
      return {
        head: { lbl: g[0] + ' · data TDS belum ada', val: gd.b, sub: 'Memakai acuan umum ' + g[1] + ' · ' + mLbl + ' ' + gd.m, st: 'warn' },
        body: rowsHtml([['Grade', g[0]], ['Material', g[1]], ['Suhu barel (acuan umum)', gd.b], [mLbl + ' (acuan umum)', gd.m], ['Sumber grade', g[3]]]) +
          notesHtml(['TDS grade ini tidak mencantumkan suhu proses; yang tampil adalah acuan umum ' + g[1] + '.'].concat(notes)),
        share: 'SUHU GRADE ' + g[0] + ' (' + g[1] + ', ' + proc + ')\nTDS tanpa data suhu; acuan umum: barel ' + gd.b + ' · ' + mLbl + ' ' + gd.m
      };
    }
  });

  /* ---- 8. Tonase Clamp ---- */
  T({
    id: 'tonase', g: 'proses', name: 'Tonase Clamp',
    def: { mode: 'IMM', shape: 'round', d: '10', l: '20', w: '10', cav: '1', runner: '10', faktor: '0.30', tinggi: '25', lebar: '10', bar: '6', sf: '1,3' },
    form: function () {
      return chips('mode', 'Proses', [['IMM', 'IMM (Injeksi)'], ['EBM', 'EBM (Blow)']], { seg: 1 }) +
        chips('shape', 'Bentuk proyeksi produk', [['round', 'Bulat / tutup'], ['box', 'Kotak / pail']], { show: 'mode:IMM' }) +
        num('d', 'Diameter luar produk', { unit: 'cm', step: 0.5, min: 0, show: 'mode:IMM;shape:round' }) +
        '<div class="row2" data-show="mode:IMM;shape:box">' + num('l', 'Panjang', { unit: 'cm', step: 0.5, min: 0 }) + num('w', 'Lebar', { unit: 'cm', step: 0.5, min: 0 }) + '</div>' +
        '<div class="row2" data-show="mode:EBM">' + num('tinggi', 'Tinggi produk', { unit: 'cm', step: 0.5, min: 0 }) + num('lebar', 'Lebar produk', { unit: 'cm', step: 0.5, min: 0 }) + '</div>' +
        num('cav', 'Cavity', { int: 1, step: 1, min: 1 }) +
        num('runner', 'Tambahan luas runner', { unit: '%', step: 5, min: 0, show: 'mode:IMM', hint: 'Isi 0 untuk hot runner tanpa runner dingin.' }) +
        chips('faktor', 'Faktor material', [['0.30', 'PE / PP (0,30)'], ['0.35', 'ABS / PS (0,35)'], ['0.50', 'PC / PET (0,50)']], { show: 'mode:IMM' }) +
        num('bar', 'Tekanan tiup', { unit: 'bar', step: 0.5, min: 0, show: 'mode:EBM' }) +
        num('sf', 'Faktor keamanan', { step: 0.1, min: 1, show: 'mode:EBM', hint: 'Cadangan untuk menjepit pinch-off dan mencegah flash. Umumnya 1,2–1,5.' });
    },
    calc: function (v) {
      if (v.mode === 'EBM') {
        var e = KT.tonaseEBM({ tinggi: P(v.tinggi), lebar: P(v.lebar), cav: P(v.cav, 1), bar: P(v.bar), sf: P(v.sf) });
        if (e.err) return e;
        return {
          head: { lbl: 'Gaya clamp minimal (EBM)', val: f(e.ton, 1) + ' ton', sub: f(e.kN, 1) + ' kN · tekanan tiup ' + f(P(v.bar), 1) + ' bar' },
          body: rowsHtml([['Luas proyeksi total', f(e.area, 1) + ' cm²'], ['Gaya akibat tekanan tiup', f(e.kNTiup, 1) + ' kN'], ['Faktor keamanan', '×' + f(e.sf, 2)],
            ['Gaya clamp minimal', f(e.kN, 1) + ' kN', 1], ['Setara', f(e.ton, 2) + ' ton', 1]]) +
            notesHtml(['Luas proyeksi = tinggi × lebar siluet produk pada bidang parting line (anggapan persegi, hasilnya sedikit lebih aman).', 'Rumus: gaya = tekanan tiup × luas proyeksi × faktor keamanan.']),
          share: 'TONASE CLAMP EBM\n' + v.tinggi + ' × ' + v.lebar + ' cm · ' + v.cav + ' cav · tiup ' + v.bar + ' bar\nMinimal ' + f(e.kN, 1) + ' kN (' + f(e.ton, 1) + ' ton)'
        };
      }
      var r = KT.tonaseIMM({ shape: v.shape, d: P(v.d), l: P(v.l), w: P(v.w), cav: P(v.cav, 1), runner: P(v.runner), faktor: P(v.faktor) });
      if (r.err) return r;
      return {
        head: { lbl: 'Tonase clamp minimal (IMM)', val: f(r.ton, 1) + ' ton', sub: f(r.kN, 0) + ' kN · dengan cadangan 10%: ' + f(r.tonCad, 1) + ' ton' },
        body: rowsHtml([['Luas proyeksi 1 pcs', f(r.a1, 1) + ' cm²'], ['Luas total + runner', f(r.total, 1) + ' cm²'], ['Faktor material', f(P(v.faktor), 2) + ' ton/cm²'],
          ['Tonase minimal', f(r.ton, 1) + ' ton', 1], ['Setara', f(r.kN, 0) + ' kN'], ['Dengan cadangan 10%', f(r.tonCad, 1) + ' ton']]) +
          notesHtml(['Kapasitas clamp mesin harus di atas angka minimal ini. Dinding sangat tipis atau aliran panjang membutuhkan faktor lebih besar.']),
        share: 'TONASE CLAMP IMM\nLuas total ' + f(r.total, 1) + ' cm² · faktor ' + f(P(v.faktor), 2) + '\nMinimal ' + f(r.ton, 1) + ' ton (' + f(r.kN, 0) + ' kN)'
      };
    }
  });

  /* ---- 9. Shot Size ---- */
  T({
    id: 'shot', g: 'proses', name: 'Shot Size',
    def: { gram: '50', runner: '0', cav: '1', kap: '' },
    form: function () {
      return num('gram', 'Berat 1 pcs produk', { unit: 'gram', step: 1, min: 0 }) + num('runner', 'Berat runner', { unit: 'gram', step: 1, min: 0, hint: 'Isi 0 untuk hot runner.' }) +
        num('cav', 'Cavity', { int: 1, step: 1, min: 1 }) + num('kap', 'Kapasitas shot maksimum mesin', { unit: 'gram', int: 1, ph: 'opsional', hint: 'Bila diisi, alat menilai persentase pemakaian barel.' });
    },
    calc: function (v) {
      var r = KT.shot({ gram: P(v.gram), runner: P(v.runner), cav: P(v.cav, 1), kap: P(v.kap, 1) });
      if (r.err) return r;
      var head = r.pakai !== undefined
        ? { lbl: 'Pemakaian kapasitas', val: f(r.pakai, 0) + '% · ' + r.verdict, sub: 'Berat per shot ' + f(r.total, 1) + ' g', st: r.status }
        : { lbl: 'Berat per shot', val: f(r.total, 1) + ' g', sub: 'Mesin ideal: kapasitas ' + f(r.minCap) + ' – ' + f(r.maxCap) + ' g' };
      var rows = [['Berat per shot (produk + runner)', f(r.total, 1) + ' g', 1], ['Kapasitas mesin ideal (30–70%)', f(r.minCap) + ' – ' + f(r.maxCap) + ' g']];
      if (r.pakai !== undefined) rows.push(['Pemakaian kapasitas', f(r.pakai, 1) + '%']);
      var notes = ['Kapasitas shot di katalog mesin umumnya dinyatakan dalam gram PS. Untuk PE/PP, kapasitas nyata kira-kira 0,8× angka katalog.'];
      if (r.why) notes.unshift(r.why);
      return { head: head, body: rowsHtml(rows) + notesHtml(notes),
        share: 'SHOT SIZE\n' + v.gram + ' g × ' + v.cav + ' cav + runner ' + (v.runner || 0) + ' g = ' + f(r.total, 1) + ' g' + (r.pakai !== undefined ? '\nPemakaian ' + f(r.pakai, 0) + '% (' + r.verdict + ')' : '') };
    }
  });

  /* ---- 10. Cooling Time ---- */
  T({
    id: 'cooling', g: 'proses', name: 'Cooling Time',
    def: { cmat: 'PP', s: '2', alpha: '0,09', tm: '230', tw: '40', te: '95' },
    form: function () {
      return chips('cmat', 'Material (mengisi nilai acuan)', Object.keys(COOL_MAT).map(function (k) { return [k, k]; })) +
        num('s', 'Tebal dinding paling tebal', { unit: 'mm', step: 0.1, min: 0.1 }) +
        '<div class="row2">' + num('tm', 'Suhu leleh', { unit: '°C', int: 1, step: 5 }) + num('tw', 'Suhu mold', { unit: '°C', int: 1, step: 5 }) + '</div>' +
        '<div class="row2">' + num('te', 'Suhu keluar', { unit: '°C', int: 1, step: 5 }) + num('alpha', 'Difusivitas', { unit: 'mm²/s', step: 0.01, min: 0.01, dec: 2 }) + '</div>';
    },
    onChip: function (k, v) { if (k === 'cmat' && COOL_MAT[v.cmat]) { var m = COOL_MAT[v.cmat]; v.alpha = m.alpha; v.tm = m.tm; v.tw = m.tw; v.te = m.te; return true; } },
    calc: function (v) {
      var r = KT.cooling({ s: P(v.s), alpha: P(v.alpha), tm: P(v.tm, 1), tw: P(v.tw, 1), te: P(v.te, 1) });
      if (r.err) return r;
      return {
        head: { lbl: 'Estimasi cooling time minimum (IMM)', val: f(r.t, 1) + ' detik', sub: 'Dinding ' + f(P(v.s), 1) + ' mm · ' + v.cmat },
        body: rowsHtml([['Tebal dinding', f(P(v.s), 1) + ' mm'], ['Suhu leleh / mold / keluar', v.tm + ' / ' + v.tw + ' / ' + v.te + ' °C'], ['Difusivitas termal', v.alpha + ' mm²/s'], ['Cooling time teoretis', f(r.t, 1) + ' detik', 1]]) +
          notesHtml(['Hasil teoretis untuk dinding didinginkan dua sisi. Di mesin biasanya lebih lama karena pendinginan mold tidak ideal; pakai sebagai titik awal lalu turunkan bertahap sambil cek warpage dan dimensi.',
            'Waktu sebanding dengan kuadrat tebal: dinding 2× lebih tebal butuh ±4× lebih lama.', 'Tidak berlaku untuk EBM (pendinginan hanya dari sisi mold).']),
        share: 'COOLING TIME (IMM)\n' + v.cmat + ' · dinding ' + v.s + ' mm · leleh ' + v.tm + '°C · mold ' + v.tw + '°C\nEstimasi minimum ' + f(r.t, 1) + ' detik'
      };
    }
  });

  /* ---- 11. Troubleshoot ---- */
  T({
    id: 'trouble', g: 'proses', name: 'Troubleshoot',
    def: { proc: 'IMM', dIMM: 'flash', dEBM: 'sag' },
    form: function () {
      return chips('proc', 'Proses', [['IMM', 'IMM (Injeksi)'], ['EBM', 'EBM (Blow)']], { seg: 1 }) +
        chips('dIMM', 'Cacat', TROUBLE.IMM.map(function (x) { return [x[0], x[1]]; }), { show: 'proc:IMM' }) +
        chips('dEBM', 'Cacat', TROUBLE.EBM.map(function (x) { return [x[0], x[1]]; }), { show: 'proc:EBM' });
    },
    calc: function (v) {
      var key = v.proc === 'EBM' ? v.dEBM : v.dIMM;
      var d = TROUBLE[v.proc].filter(function (x) { return x[0] === key; })[0] || TROUBLE[v.proc][0];
      return {
        head: { lbl: 'Troubleshoot ' + v.proc, val: d[1], sub: d[2] },
        body: '<p style="margin:0 0 6px;font-size:12.5px;color:var(--ink2)">Kerjakan berurutan, satu perubahan per langkah, lalu amati beberapa siklus.</p><ol class="steps">' +
          d[3].map(function (s) { return '<li>' + s + '</li>'; }).join('') + '</ol>',
        share: 'TROUBLESHOOT ' + v.proc + ': ' + d[2] + '\n' + d[3].map(function (s, i) { return (i + 1) + '. ' + s; }).join('\n')
      };
    }
  });

  /* ---- 12. Ulir ---- */
  T({
    id: 'ulir', g: 'bengkel', name: 'Identifikasi Ulir',
    def: { od: '', mode: 'tpi', pitch: '' },
    form: function () {
      return num('od', 'Diameter luar ulir terukur', { unit: 'mm', step: 0.1, min: 0, ph: 'mis. 20,9' }) +
        chips('mode', 'Satuan kerapatan', [['tpi', 'TPI (ulir per inch)'], ['mm', 'Pitch (mm)']], { seg: 1 }) +
        num('pitch', 'Kerapatan ulir', { step: 0.5, min: 0, ph: 'opsional', hint: 'Ukur dengan pitch gauge. Tanpa kerapatan, BSP dan NPT ukuran sama sering tertukar.' });
    },
    calc: function (v) {
      var r = KT.ulir({ od: P(v.od), pitch: P(v.pitch), mode: v.mode });
      var ref = refTable();
      if (r.err) return { err: r.err, bodyOnErr: ref };
      if (!r.list.length) return { head: { lbl: 'Ulir tidak ditemukan', val: 'Tidak ada yang cocok', sub: 'Periksa ulang diameter/kerapatan', st: 'warn' }, body: ref };
      var best = r.list[0].t;
      var body = r.list.map(function (c, i) {
        var t = c.t;
        return '<div class="cand' + (i === 0 ? ' best' : '') + '"><b>' + t.std + ' ' + t.size + '</b><small>Diameter ' + f(t.od, 2).replace(/,?0+$/, '') + ' mm (selisih ' + f(c.d, 2) + ') · ' +
          (t.tpi ? f(t.tpi, 1).replace(/,0$/, '') + ' TPI · pitch ' + f(t.pitch, 3) + ' mm' : 'pitch ' + f(t.pitch, 2).replace(/,?0+$/, '') + ' mm') + '</small><small>' + KT.THREAD_INFO[t.std] + '</small></div>';
      }).join('');
      var w = r.pitchMm ? [] : ['Kerapatan belum diisi; kandidat hanya berdasarkan diameter. Ukur dengan pitch gauge untuk memastikan.'];
      var stds = r.list.map(function (c) { return c.t.std; });
      if (stds.indexOf('BSP') >= 0 && stds.indexOf('NPT') >= 0) w.push('BSP dan NPT ukuran ini mirip. Bedakan dengan thread gauge: sudut puncak ulir 55° (BSP) atau 60° (NPT); BSP berpuncak membulat, NPT berpuncak rata.');
      return {
        head: { lbl: 'Kemungkinan terbesar', val: best.std + ' ' + best.size, sub: r.list.length > 1 ? 'Ada ' + (r.list.length - 1) + ' kandidat lain di bawah' : 'Satu kandidat cocok' },
        body: notesHtml([], w) + body + ref,
        share: 'IDENTIFIKASI ULIR\nTerukur ' + v.od + ' mm' + (r.pitchMm ? ' · ' + v.pitch + (v.mode === 'mm' ? ' mm' : ' TPI') : '') + '\nKandidat: ' + r.list.map(function (c) { return c.t.std + ' ' + c.t.size; }).join(', ')
      };
    }
  });
  function refTable() {
    var by = {};
    KT.THREADS.forEach(function (t) { (by[t.std] = by[t.std] || []).push(t); });
    return Object.keys(by).map(function (s) {
      return '<details class="ref"><summary>Tabel ' + s + '</summary><table class="refTbl"><tr><th>Ukuran</th><th>Diameter (mm)</th><th>' + (by[s][0].tpi ? 'TPI' : 'Pitch (mm)') + '</th></tr>' +
        by[s].map(function (t) { return '<tr><td>' + t.size + '</td><td>' + String(t.od).replace('.', ',') + '</td><td>' + String(t.tpi || t.pitch).replace('.', ',') + '</td></tr>'; }).join('') + '</table></details>';
    }).join('');
  }

  /* ---- 13. Konversi ---- */
  var CONV_GROUPS = [['tekanan', 'Tekanan', 'bar', '100'], ['gaya', 'Gaya', 'ton-f', '1'], ['suhu', 'Suhu', '°C', '220'], ['panjang', 'Panjang', 'inch', '1'], ['torsi', 'Torsi', 'N·m', '100']];
  function convUnits(g) { return g === 'suhu' ? ['°C', '°F'] : Object.keys(KT.CONV[g].units); }
  T({
    id: 'konversi', g: 'bengkel', name: 'Konversi Satuan', conv: true,
    def: (function () { var d = { cg: 'tekanan' }; CONV_GROUPS.forEach(function (c) { d['cu_' + c[0]] = c[2]; d['cv_' + c[0]] = c[3]; }); return d; })(),
    form: function () {
      return chips('cg', 'Jenis besaran', CONV_GROUPS.map(function (c) { return [c[0], c[1]]; })) +
        CONV_GROUPS.map(function (c) {
          return '<div data-show="cg:' + c[0] + '">' + convUnits(c[0]).map(function (u) {
            var id = 'cv_' + c[0] + '_' + u.replace(/[^a-z0-9]/gi, '');
            return '<div class="fld"><label for="' + id + '">' + u + '</label><div class="num"><input id="' + id + '" data-conv="' + c[0] + '" data-unit="' + u + '" inputmode="' + (c[0] === 'suhu' ? 'text' : 'decimal') + '" autocomplete="off" enterkeyhint="done"></div></div>';
          }).join('') + '</div>';
        }).join('') + '<span class="hint" style="margin:-6px 0 14px">Ketik di kotak mana saja; kotak lain menyesuaikan. Suhu boleh negatif (ketik tanda minus).</span>';
    },
    calc: function (v) {
      var g = v.cg, u = v['cu_' + g], val = P(v['cv_' + g]);
      if (!isFinite(val)) return { err: 'Ketik angka pada salah satu kotak.' };
      var out = KT.convert(g, u, val);
      var lines = convUnits(g).filter(function (x) { return x !== u; }).map(function (x) { return fs(out[x]) + ' ' + x; });
      return {
        head: { lbl: 'Konversi ' + g, val: fs(val) + ' ' + u, sub: '= ' + lines.join(' = ') },
        body: rowsHtml(convUnits(g).map(function (x) { return [x, fs(out[x]), x === u]; })) +
          (g === 'gaya' ? notesHtml(['1 ton-force = 9,80665 kN (gravitasi standar), sama dengan tab Tonase.']) : ''),
        share: 'KONVERSI ' + g.toUpperCase() + '\n' + fs(val) + ' ' + u + ' = ' + lines.join(' = '),
        convOut: out
      };
    }
  });

  /* =====================================================================
     MESIN TAMPILAN
     ===================================================================== */
  var byId = {}; TOOLS.forEach(function (t) { byId[t.id] = t; });
  var state = {};
  TOOLS.forEach(function (t) {
    var saved = lsGet('v_' + t.id, null) || {};
    var v = {}; Object.keys(t.def).forEach(function (k) { v[k] = saved[k] !== undefined ? saved[k] : t.def[k]; });
    state[t.id] = v;
  });
  var cur = null;
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };

  function presets() { return lsGet('presets', []); }
  function setPresets(L) { lsSet('presets', L); }

  function build() {
    // Datalist mesin
    var dl = document.createElement('datalist'); dl.id = 'dlMesin';
    dl.innerHTML = MESIN.UBS3.concat(MESIN.UBS1).map(function (m) { return '<option value="' + m + '">'; }).join('');
    document.body.appendChild(dl);

    // Menu bawah & sidebar
    $('#bnav').innerHTML = GROUPS.map(function (g) { return '<button type="button" data-group="' + g[0] + '">' + g[2] + '<span>' + g[1] + '</span></button>'; }).join('');
    $('#side').innerHTML = GROUPS.map(function (g) {
      return '<h3>' + g[1] + '</h3>' + TOOLS.filter(function (t) { return t.g === g[0]; }).map(function (t) { return '<button type="button" data-tool="' + t.id + '">' + t.name + '</button>'; }).join('');
    }).join('');

    // Halaman alat
    $('#tools').innerHTML = TOOLS.map(function (t) {
      return '<section class="tool" id="t-' + t.id + '" data-id="' + t.id + '">' +
        '<div class="card"><div class="cardH"><h2>' + t.name + '</h2><button type="button" class="txtBtn" data-act="reset">Atur ulang</button></div><div class="cardB">' + t.form() + '</div></div>' +
        '<div class="card"><div class="cardH"><h2>Rincian</h2></div><div class="cardB detail"></div></div></section>';
    }).join('');
    TOOLS.forEach(function (t) { fillInputs(t.id); });
  }

  function fillInputs(id) {
    var sec = $('#t-' + id), v = state[id];
    $$('input[data-k]', sec).forEach(function (inp) { inp.value = v[inp.dataset.k] === undefined ? '' : v[inp.dataset.k]; });
    $$('[data-ck]', sec).forEach(function (box) {
      $$('button', box).forEach(function (b) { b.classList.toggle('on', b.dataset.v === String(v[box.dataset.ck])); });
    });
    if (byId[id].conv) fillConv(id, null);
    if (byId[id].preset) fillPresetSelect(sec);
    applyShow(id);
  }

  function fillPresetSelect(sec) {
    var L = presets();
    var sel = $('select[data-preset]', sec); if (!sel) return;
    sel.innerHTML = '<option value="">' + (L.length ? 'Pilih preset mesin…' : 'Belum ada preset') + '</option>' +
      L.map(function (p) { return '<option value="' + esc(p.id) + '">' + esc(p.mesin) + (p.mould ? ' · ' + esc(p.mould) : '') + ' — CT ' + esc(p.ct) + ' · ' + esc(p.cav) + ' cav</option>'; }).join('');
  }

  function applyShow(id) {
    var sec = $('#t-' + id), v = state[id];
    $$('[data-show]', sec).forEach(function (el) {
      var okk = el.dataset.show.split(';').every(function (c) { var p = c.split(':'); return p[1].split('|').indexOf(String(v[p[0]])) >= 0; });
      el.style.display = okk ? '' : 'none';
    });
  }

  function fillConv(id, skipInput) {
    var v = state[id];
    CONV_GROUPS.forEach(function (c) {
      var g = c[0], val = P(v['cv_' + g]), u = v['cu_' + g];
      var out = isFinite(val) ? KT.convert(g, u, val) : null;
      $$('input[data-conv="' + g + '"]', $('#t-' + id)).forEach(function (inp) {
        if (inp === skipInput) return;
        if (inp.dataset.unit === u) inp.value = v['cv_' + g];
        else inp.value = out ? fin(out[inp.dataset.unit], Math.abs(out[inp.dataset.unit]) >= 100 ? 2 : 4) : '';
      });
    });
  }

  var lastShare = '';
  function render() {
    var t = byId[cur], v = state[cur], r;
    try { r = t.calc(v); } catch (e) { r = { err: 'Terjadi kesalahan hitung. Periksa isian.' }; if (window.console) console.error(e); }
    var hr = $('#headRes');
    hr.className = 'headRes' + (r && r.head && r.head.st ? ' ' + r.head.st : '');
    var actions = '<div class="hrAct">' + (t.noShare ? '' : '<button type="button" class="iconBtn" data-act="share" aria-label="Bagikan" title="Bagikan / salin"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7M12 3v13M7 8l5-5 5 5"/></svg></button>') + '</div>';
    if (r.err) {
      hr.innerHTML = '<div class="hrTx"><div class="hrLbl">' + t.name + '</div><div class="hrErr">' + r.err + '</div></div>';
      $('#t-' + cur + ' .detail').innerHTML = (r.bodyOnErr || '') || '<div class="empty">Rincian muncul setelah isian lengkap.</div>';
      lastShare = '';
      return;
    }
    hr.innerHTML = '<div class="hrTx"><div class="hrLbl">' + r.head.lbl + '</div><div class="hrVal">' + r.head.val + '</div>' + (r.head.sub ? '<div class="hrSub">' + r.head.sub + '</div>' : '') + '</div>' + actions;
    $('#t-' + cur + ' .detail').innerHTML = r.body || '';
    lastShare = r.share || '';
  }

  function save(id) { lsSet('v_' + id, state[id]); }

  function go(id, opt) {
    if (!byId[id]) id = 'output';
    cur = id;
    var t = byId[id];
    $$('.tool').forEach(function (s) { s.classList.toggle('on', s.dataset.id === id); });
    $$('#bnav button').forEach(function (b) { b.classList.toggle('on', b.dataset.group === t.g); });
    $$('#side button').forEach(function (b) { b.classList.toggle('on', b.dataset.tool === id); });
    $('#toolBar').innerHTML = TOOLS.filter(function (x) { return x.g === t.g; }).map(function (x) { return '<button type="button" data-tool="' + x.id + '" class="' + (x.id === id ? 'on' : '') + '">' + x.name + '</button>'; }).join('');
    var onb = $('#toolBar .on'); if (onb && onb.scrollIntoView) { try { onb.scrollIntoView({ block: 'nearest', inline: 'center' }); } catch (e) { } }
    if (t.preset) fillPresetSelect($('#t-' + id));
    lsSet('last', id);
    lsSet('lastIn_' + t.g, id);
    if (location.hash !== '#' + id) { try { history.replaceState(null, '', '#' + id); } catch (e) { location.hash = id; } }
    render();
    if (!opt || !opt.keepScroll) window.scrollTo(0, 0);
  }

  /* ---------- Peristiwa ---------- */
  document.addEventListener('input', function (e) {
    var el = e.target;
    var sec = el.closest && el.closest('.tool'); if (!sec) return;
    var id = sec.dataset.id;
    if (el.dataset.conv) {
      var g = el.dataset.conv;
      state[id]['cv_' + g] = el.value; state[id]['cu_' + g] = el.dataset.unit;
      fillConv(id, el); save(id); if (id === cur) render(); return;
    }
    if (!el.dataset.k) return;
    var val = el.value;
    if (el.dataset.txt && el.list) { var up = val.toUpperCase(); if (up !== val) { var p = el.selectionStart; el.value = up; try { el.setSelectionRange(p, p); } catch (x) { } val = up; } }
    state[id][el.dataset.k] = val;
    save(id);
    if (id === cur) render();
  });

  var holdT = null, holdI = null;
  function stepBtn(b) {
    var inp = b.parentNode.querySelector('input'); var sec = b.closest('.tool'); var id = sec.dataset.id;
    var isInt = !!inp.dataset.int, d = parseFloat(b.dataset.step);
    var cv = P(inp.value, isInt);
    if (!isFinite(cv)) { var dv = P(byId[id].def[inp.dataset.k], isInt); cv = isFinite(dv) ? dv : 0; }
    var dec = inp.dataset.dec !== undefined ? +inp.dataset.dec : (String(Math.abs(d)).split('.')[1] || '').length;
    var stepDec = (String(Math.abs(d)).split('.')[1] || '').length;
    // Lompat ke kelipatan langkah terdekat agar tidak "12,3 → 12,8"
    var nv = d > 0 ? Math.floor(cv / d + 1e-9) * d + d : Math.ceil(cv / -d - 1e-9) * -d + d;
    if (Math.abs(nv - cv) > Math.abs(d) + 1e-9) nv = cv + d;
    var mn = inp.dataset.min !== undefined ? parseFloat(inp.dataset.min) : -Infinity;
    if (nv < mn) nv = mn;
    var s = fin(nv, Math.max(dec, stepDec, (String(mn).split('.')[1] || '').length));
    inp.value = s;
    state[id][inp.dataset.k] = s; save(id); if (id === cur) render();
  }
  function stopHold() { clearTimeout(holdT); clearInterval(holdI); holdT = holdI = null; }
  document.addEventListener('pointerdown', function (e) {
    var b = e.target.closest && e.target.closest('.st'); if (!b) return;
    e.preventDefault(); stepBtn(b); stopHold();
    holdT = setTimeout(function () { holdI = setInterval(function () { stepBtn(b); }, 90); }, 450);
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (ev) { document.addEventListener(ev, stopHold); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.tagName === 'INPUT') e.target.blur(); });

  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('button'); if (!b) return;
    if (b.classList.contains('st')) return; // ditangani pointerdown
    if (b.dataset.group) { var g = b.dataset.group; var last = lsGet('lastIn_' + g, null); go(last && byId[last] && byId[last].g === g ? last : TOOLS.filter(function (t) { return t.g === g; })[0].id); return; }
    if (b.dataset.tool) { go(b.dataset.tool); return; }
    var sec = b.closest('.tool'); var id = sec ? sec.dataset.id : cur;
    var box = b.closest('[data-ck]');
    if (box && sec) {
      var k = box.dataset.ck; state[id][k] = b.dataset.v;
      var t = byId[id]; if (t.onChip && t.onChip(k, state[id])) fillInputs(id);
      $$('button', box).forEach(function (x) { x.classList.toggle('on', x === b); });
      applyShow(id); save(id); render(); return;
    }
    if (b.dataset.set && sec) {
      state[id][b.dataset.set] = b.dataset.v; var inp = $('input[data-k="' + b.dataset.set + '"]', sec); if (inp) inp.value = b.dataset.v;
      save(id); render(); return;
    }
    var act = b.dataset.act;
    if (act === 'reset') {
      var t2 = byId[id]; state[id] = JSON.parse(JSON.stringify(t2.def)); save(id); fillInputs(id); render(); toast('Isian dikembalikan ke awal'); return;
    }
    if (act === 'share') { doShare(); return; }
    if (act === 'savePreset') {
      var v = state[id]; var ct = P(v.ct), cav = P(v.cav, 1);
      if (!v.mesin || !(ct > 0) || !(cav > 0)) { toast('Isi Mesin, Cycle time, dan Cavity dahulu'); return; }
      var L = presets();
      var dup = L.filter(function (p) { return p.mesin === v.mesin && P(p.ct) === ct && P(p.cav, 1) === cav; })[0];
      if (dup) { toast('Preset ini sudah ada'); return; }
      L.push({ id: String(Date.now()), mesin: v.mesin, mould: '', ct: fin(ct, 2), cav: String(cav) });
      setPresets(L); fillPresetSelect(sec); toast('Preset ' + v.mesin + ' tersimpan'); return;
    }
    if (act === 'addPreset') {
      var pv = state.preset; var pct2 = P(pv.pCt), pcav = P(pv.pCav, 1);
      if (!pv.pMesin || !(pct2 > 0) || !(pcav > 0)) { toast('Isi Mesin, Cycle time, dan Cavity'); return; }
      var L2 = presets(); L2.push({ id: String(Date.now()), mesin: pv.pMesin.trim(), mould: (pv.pMould || '').trim(), ct: fin(pct2, 2), cav: String(pcav) });
      setPresets(L2); state.preset = JSON.parse(JSON.stringify(byId.preset.def)); save('preset'); fillInputs('preset'); render(); toast('Preset ditambahkan'); return;
    }
    if (act === 'delPreset') {
      var L3 = presets().filter(function (p) { return p.id !== b.dataset.id; });
      setPresets(L3); render(); toast('Preset dihapus'); return;
    }
  });

  document.addEventListener('change', function (e) {
    var sel = e.target; if (!sel.dataset || !sel.dataset.preset) return;
    var sec = sel.closest('.tool'), id = sec.dataset.id;
    var p = presets().filter(function (x) { return x.id === sel.value; })[0];
    if (!p) return;
    state[id].mesin = p.mesin; state[id].ct = p.ct; state[id].cav = p.cav;
    save(id); fillInputs(id); sel.value = ''; render(); toast('Preset ' + p.mesin + ' dipakai');
  });

  /* ---------- Bagikan ---------- */
  function doShare() {
    if (!lastShare) { toast('Belum ada hasil untuk dibagikan'); return; }
    var text = lastShare + '\n— Kalkulator Teknik Mekanik UBS';
    if (navigator.share) {
      navigator.share({ text: text }).catch(function (err) { if (err && err.name !== 'AbortError') copyText(text); });
    } else copyText(text);
  }
  function copyText(text) {
    function fallback() {
      var ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.top = '-1000px';
      document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, text.length);
      var okk = false; try { okk = document.execCommand('copy'); } catch (e) { }
      document.body.removeChild(ta); toast(okk ? 'Hasil disalin' : 'Gagal menyalin');
    }
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(function () { toast('Hasil disalin'); }, fallback);
    else fallback();
  }
  var toastT;
  function toast(m) { var el = $('#toast'); el.textContent = m; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { el.classList.remove('show'); }, 1800); }

  /* ---------- Mulai ---------- */
  build();
  $('#ver').textContent = 'Versi ' + VER;
  $('#hubLink').href = LINK_HUB;
  var startId = (location.hash || '').replace('#', '');
  go(byId[startId] ? startId : (lsGet('last', 'output')));
  window.addEventListener('hashchange', function () { var h = location.hash.replace('#', ''); if (byId[h] && h !== cur) go(h); });

  if ('serviceWorker' in navigator && location.protocol === 'https:') {
    window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () { }); });
  }
  window.__KT_APP = { state: state, go: go, TOOLS: TOOLS };
})();
