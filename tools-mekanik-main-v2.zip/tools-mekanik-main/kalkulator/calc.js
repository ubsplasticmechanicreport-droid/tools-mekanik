/* Kalkulator Teknik UBS — fungsi hitung murni (tanpa DOM).
   Dipakai oleh app.js dan oleh uji otomatis (Node). */
(function (root) {
  'use strict';
  var G = 9.80665;

  /* Baca angka dari isian. Menerima koma atau titik sebagai desimal.
     isInt=true: semua titik/koma dianggap pemisah ribuan (1.500 = 1500). */
  function parseNum(v, isInt) {
    if (v === null || v === undefined) return NaN;
    var s = String(v).trim().replace(/\s/g, '');
    if (s === '') return NaN;
    if (isInt) {
      s = s.replace(/[.,]/g, '');
      if (!/^-?\d+$/.test(s)) return NaN;
      return parseInt(s, 10);
    }
    var hasDot = s.indexOf('.') >= 0, hasCom = s.indexOf(',') >= 0;
    if (hasDot && hasCom) {
      // Format Indonesia: 1.234,5
      if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(/\./g, '').replace(',', '.');
      else s = s.replace(/,/g, ''); // format Inggris: 1,234.5
    } else if (hasCom) {
      if ((s.match(/,/g) || []).length > 1) return NaN;
      s = s.replace(',', '.');
    } else if ((s.match(/\./g) || []).length > 1) {
      return NaN;
    }
    if (!/^-?(\d+\.?\d*|\.\d+)$/.test(s)) return NaN;
    return parseFloat(s);
  }

  function ok(x) { return typeof x === 'number' && isFinite(x); }
  function pos(x) { return ok(x) && x > 0; }

  /* ===== PRODUKSI ===== */
  function output(i) {
    // i: jam, ct, cav, down (menit), aktual (pcs, opsional), rej, rejMode ('pct'|'pcs')
    if (!pos(i.jam) || !pos(i.ct) || !pos(i.cav)) return { err: 'Isi durasi, cycle time, dan cavity.' };
    var avail = i.jam * 60;
    var down = ok(i.down) && i.down > 0 ? i.down : 0;
    var warn = [];
    if (down > avail) { down = avail; warn.push('Downtime melebihi durasi; dibatasi sama dengan durasi.'); }
    var run = avail - down;
    var perMin = 60 / i.ct * i.cav;            // pcs per menit ideal
    var raw = Math.floor(avail * perMin);
    var potensiF = run * perMin;
    var potensi = Math.floor(potensiF);
    var A = run / avail;
    var hasAkt = pos(i.aktual);
    var total = hasAkt ? Math.round(i.aktual) : potensi;
    var rej = 0;
    var rv = ok(i.rej) && i.rej > 0 ? i.rej : 0;
    if (i.rejMode === 'pcs') rej = Math.round(rv);
    else {
      if (rv > 100) { rv = 100; warn.push('Reject melebihi 100%; dibatasi 100%.'); }
      rej = Math.round(total * rv / 100);
    }
    if (rej > total) { rej = total; warn.push('Reject melebihi total output; dibatasi.'); }
    var good = total - rej;
    var P = hasAkt ? (potensiF > 0 ? total / potensiF : 0) : 1;
    if (hasAkt && P > 1.0001) warn.push('Performance di atas 100%: CT standar yang diisi lebih lambat dari CT aktual mesin, atau data output keliru.');
    var Q = total > 0 ? good / total : 0;
    var oee = A * P * Q;
    return { avail: avail, down: down, run: run, raw: raw, potensi: potensi, total: total, rej: rej, good: good,
      A: A, P: P, Q: Q, oee: oee, estimasi: !hasAkt, perJam: perMin * 60, warn: warn };
  }

  function target(i) {
    // i: qty, ct, cav, eff (%), jamShift
    if (!pos(i.qty) || !pos(i.ct) || !pos(i.cav)) return { err: 'Isi target, cycle time, dan cavity.' };
    var eff = pos(i.eff) ? Math.min(i.eff, 100) : 100;
    var jamShift = pos(i.jamShift) ? i.jamShift : 8;
    var shots = Math.ceil(i.qty / i.cav);
    var jamBersih = shots * i.ct / 3600;
    var jamNyata = jamBersih / (eff / 100);
    return { shots: shots, jamBersih: jamBersih, jamNyata: jamNyata, shift: jamNyata / jamShift,
      hari: jamNyata / 24, perJamIdeal: 3600 / i.ct * i.cav, perJamNyata: 3600 / i.ct * i.cav * eff / 100,
      eff: eff, jamShift: jamShift };
  }

  function downtime(i) {
    // i: menit, ct, cav, harga (Rp/pcs, opsional)
    if (!pos(i.menit) || !pos(i.ct) || !pos(i.cav)) return { err: 'Isi lama mesin mati, cycle time, dan cavity.' };
    var shots = Math.floor(i.menit * 60 / i.ct);
    var pcs = Math.floor(i.menit * 60 / i.ct * i.cav);
    return { shots: shots, pcs: pcs, rupiah: pos(i.harga) ? pcs * i.harga : null,
      perJam: 3600 / i.ct * i.cav };
  }

  /* ===== LISTRIK ===== */
  function heater(i) {
    // i: watt (nameplate, opsional), volt, ohm (terukur, opsional)
    if (!pos(i.volt)) return { err: 'Isi tegangan.' };
    var hasW = pos(i.watt), hasR = pos(i.ohm);
    if (!hasW && !hasR) return { err: 'Isi daya nameplate dan/atau Ohm terukur.' };
    var r = { volt: i.volt, hasW: hasW, hasR: hasR };
    if (hasW) { r.rNom = i.volt * i.volt / i.watt; r.iNom = i.watt / i.volt; }
    if (hasR) { r.pAkt = i.volt * i.volt / i.ohm; r.iAkt = i.volt / i.ohm; }
    if (hasW && hasR) {
      r.dev = (i.ohm - r.rNom) / r.rNom * 100;
      var a = Math.abs(r.dev);
      var ratio = i.ohm / r.rNom;
      if (ratio >= 10) { r.status = 'bad'; r.verdict = 'PUTUS / TERBUKA'; r.why = 'Resistansi jauh di atas nilai seharusnya. Elemen putus atau sambungan terminal lepas.'; }
      else if (a <= 10) { r.status = 'ok'; r.verdict = 'NORMAL'; r.why = 'Resistansi dalam toleransi ±10% dari nameplate.'; }
      else if (a <= 20) { r.status = 'warn'; r.verdict = 'PERLU DIPANTAU'; r.why = 'Menyimpang 10–20%. Ukur ulang dalam keadaan dingin; periksa terminal dan kabel.'; }
      else if (r.dev > 0) { r.status = 'bad'; r.verdict = 'MELEMAH'; r.why = 'Resistansi terlalu tinggi; daya heater turun. Kemungkinan elemen menipis atau sambungan berkarat/longgar.'; }
      else { r.status = 'bad'; r.verdict = 'TERLALU RENDAH'; r.why = 'Resistansi terlalu rendah; arus berlebih. Kemungkinan hubung singkat sebagian, atau heater bukan untuk tegangan ini.'; }
      // Petunjuk salah tegangan (heater 220V vs 380V)
      var k = (380 * 380) / (220 * 220); // ≈ 2,98
      if (ratio > k * 0.85 && ratio < k * 1.15) r.hint = 'Nilai ≈3× resistansi seharusnya: kemungkinan heater ini untuk 380V, bukan ' + i.volt + 'V.';
      else if (ratio > (1 / k) * 0.85 && ratio < (1 / k) * 1.15) r.hint = 'Nilai ≈⅓ resistansi seharusnya: kemungkinan heater ini untuk 220V, bukan ' + i.volt + 'V.';
    }
    return r;
  }

  var SSR_SIZES = [10, 15, 25, 40, 50, 60, 75, 80, 90, 100, 120];
  function ssr(i) {
    // i: watt (total beban per SSR), volt, suhu (°C panel)
    if (!pos(i.watt) || !pos(i.volt)) return { err: 'Isi daya beban dan tegangan.' };
    var amp = i.watt / i.volt;
    var suhu = ok(i.suhu) ? i.suhu : 40;
    var derate = suhu > 40 ? 1 + 0.025 * (suhu - 40) : 1;
    var minA = amp * 1.5 * derate;
    var recA = amp * 2 * derate;
    var pick = null;
    for (var k = 0; k < SSR_SIZES.length; k++) if (SSR_SIZES[k] >= recA) { pick = SSR_SIZES[k]; break; }
    return { amp: amp, derate: derate, minA: minA, recA: recA, pick: pick, suhu: suhu,
      vRating: i.volt > 250 ? 'minimal 480 VAC (mis. 48–480 VAC)' : '24–380 VAC atau 24–480 VAC',
      heatsink: pick === null || pick >= 25 };
  }

  /* ===== PROSES ===== */
  function tonaseIMM(i) {
    // i: shape ('round'|'box'), d, l, w (cm), cav, runner (%), faktor (ton/cm²)
    if (!pos(i.cav) || !pos(i.faktor)) return { err: 'Isi cavity dan faktor material.' };
    var a1;
    if (i.shape === 'box') { if (!pos(i.l) || !pos(i.w)) return { err: 'Isi panjang dan lebar produk.' }; a1 = i.l * i.w; }
    else { if (!pos(i.d)) return { err: 'Isi diameter produk.' }; a1 = Math.PI / 4 * i.d * i.d; }
    var run = ok(i.runner) && i.runner > 0 ? i.runner : 0;
    var total = a1 * i.cav * (1 + run / 100);
    var ton = total * i.faktor;
    return { a1: a1, total: total, ton: ton, kN: ton * G, tonCad: ton * 1.1 };
  }

  function tonaseEBM(i) {
    // i: tinggi, lebar (cm, siluet pada bidang parting line), cav, bar (tekanan tiup), sf
    if (!pos(i.tinggi) || !pos(i.lebar) || !pos(i.cav) || !pos(i.bar)) return { err: 'Isi tinggi, lebar, cavity, dan tekanan tiup.' };
    var sf = pos(i.sf) ? i.sf : 1.3;
    var area = i.tinggi * i.lebar * i.cav;          // cm²
    var kNTiup = i.bar * area / 100;                 // bar×cm² → kN (1 bar×1 cm² = 10 N)
    var kN = kNTiup * sf;
    return { area: area, kNTiup: kNTiup, kN: kN, ton: kN / G, sf: sf };
  }

  function shot(i) {
    // i: gram (1 pcs), runner (g), cav, kap (kapasitas maks mesin, g, opsional)
    if (!pos(i.gram) || !pos(i.cav)) return { err: 'Isi berat produk dan cavity.' };
    var runner = ok(i.runner) && i.runner > 0 ? i.runner : 0;
    var total = i.gram * i.cav + runner;
    var r = { total: total, minCap: total / 0.7, maxCap: total / 0.3 };
    if (pos(i.kap)) {
      r.pakai = total / i.kap * 100;
      if (r.pakai > 85) { r.status = 'bad'; r.verdict = 'TERLALU BESAR'; r.why = 'Mendekati batas kapasitas: rawan short shot dan leleh tidak homogen.'; }
      else if (r.pakai > 70) { r.status = 'warn'; r.verdict = 'BATAS ATAS'; r.why = 'Masih bisa jalan, tetapi tidak ada cadangan dosing.'; }
      else if (r.pakai >= 30) { r.status = 'ok'; r.verdict = 'IDEAL'; r.why = 'Pemakaian 30–70% dari kapasitas.'; }
      else if (r.pakai >= 20) { r.status = 'warn'; r.verdict = 'BATAS BAWAH'; r.why = 'Waktu tinggal material di barel cukup lama; awasi degradasi.'; }
      else { r.status = 'bad'; r.verdict = 'TERLALU KECIL'; r.why = 'Material terlalu lama di barel: risiko degradasi, bintik hitam, dan silver.'; }
    }
    return r;
  }

  function cooling(i) {
    // i: s (tebal dinding, mm), alpha (mm²/s), tm, tw, te (°C)
    if (!pos(i.s) || !pos(i.alpha) || !ok(i.tm) || !ok(i.tw) || !ok(i.te)) return { err: 'Isi tebal dinding, difusivitas, dan ketiga suhu.' };
    if (!(i.te > i.tw)) return { err: 'Suhu keluar (ejeksi) harus lebih tinggi dari suhu mold.' };
    if (!(i.tm > i.te)) return { err: 'Suhu leleh harus lebih tinggi dari suhu keluar (ejeksi).' };
    var arg = (8 / (Math.PI * Math.PI)) * (i.tm - i.tw) / (i.te - i.tw);
    if (!(arg > 1)) return { err: 'Kombinasi suhu di luar jangkauan rumus (hasil ≤ 0).' };
    var t = i.s * i.s / (Math.PI * Math.PI * i.alpha) * Math.log(arg);
    return { t: t };
  }

  /* ===== BENGKEL: ULIR ===== */
  var THREADS = (function () {
    var L = [];
    function add(std, size, od, tpi, pitch) { L.push({ std: std, size: size, od: od, pitch: pitch || 25.4 / tpi, tpi: tpi || null }); }
    // BSP (Whitworth 55°) — G = lurus (BSPP), R = tirus (BSPT); diameter mayor
    [['1/8"', 9.728, 28], ['1/4"', 13.157, 19], ['3/8"', 16.662, 19], ['1/2"', 20.955, 14], ['5/8"', 22.911, 14],
     ['3/4"', 26.441, 14], ['1"', 33.249, 11], ['1 1/4"', 41.910, 11], ['1 1/2"', 47.803, 11], ['2"', 59.614, 11]]
      .forEach(function (a) { add('BSP', a[0], a[1], a[2]); });
    // NPT (60°, tirus) — diameter luar pipa
    [['1/8"', 10.29, 27], ['1/4"', 13.72, 18], ['3/8"', 17.15, 18], ['1/2"', 21.34, 14], ['3/4"', 26.67, 14],
     ['1"', 33.40, 11.5], ['1 1/4"', 42.16, 11.5], ['1 1/2"', 48.26, 11.5], ['2"', 60.33, 11.5]]
      .forEach(function (a) { add('NPT', a[0], a[1], a[2]); });
    // UNF / UN (60°, lurus) — umum pada fitting hidrolik JIC 37°
    [['7/16"-20', 11.11, 20], ['1/2"-20', 12.70, 20], ['9/16"-18', 14.29, 18], ['3/4"-16', 19.05, 16], ['7/8"-14', 22.23, 14],
     ['1 1/16"-12', 26.99, 12], ['1 3/16"-12', 30.16, 12], ['1 5/16"-12', 33.34, 12], ['1 5/8"-12', 41.28, 12], ['1 7/8"-12', 47.63, 12]]
      .forEach(function (a) { add('UNF', a[0], a[1], a[2]); });
    // Metrik halus (fitting hidrolik DIN) dan kasar (baut)
    [[8, 1], [10, 1], [12, 1.5], [14, 1.5], [16, 1.5], [18, 1.5], [20, 1.5], [22, 1.5], [24, 1.5], [26, 1.5],
     [27, 2], [30, 2], [33, 2], [36, 2], [42, 2], [45, 2], [48, 2], [52, 2]]
      .forEach(function (a) { add('Metrik halus', 'M' + a[0] + '×' + String(a[1]).replace('.', ','), a[0], null, a[1]); });
    [[6, 1], [8, 1.25], [10, 1.5], [12, 1.75], [14, 2], [16, 2], [18, 2.5], [20, 2.5], [22, 2.5], [24, 3], [27, 3], [30, 3.5]]
      .forEach(function (a) { add('Metrik kasar', 'M' + a[0] + '×' + String(a[1]).replace('.', ','), a[0], null, a[1]); });
    return L;
  })();

  var THREAD_INFO = {
    'BSP': 'Sudut 55°. G (BSPP) lurus — kedap dengan seal/O-ring/bonded seal. R/Rc (BSPT) tirus — kedap dengan seal tape.',
    'NPT': 'Sudut 60°, tirus (standar Amerika). Kedap dengan seal tape/sealant. Jangan dipasangkan dengan BSP.',
    'UNF': 'Sudut 60°, lurus. Umum pada fitting hidrolik JIC 37° dan ORFS; kedap di dudukan flare/O-ring, bukan di ulir.',
    'Metrik halus': 'Sudut 60°, lurus, pitch halus. Umum pada fitting hidrolik DIN (24° cone) mesin Eropa.',
    'Metrik kasar': 'Sudut 60°, lurus, pitch standar. Umumnya baut/mur, bukan fitting.'
  };

  function ulir(i) {
    // i: od (mm), pitch (nilai), mode ('tpi'|'mm')
    if (!pos(i.od)) return { err: 'Isi diameter luar ulir terukur.' };
    var pitchMm = null;
    if (pos(i.pitch)) pitchMm = i.mode === 'mm' ? i.pitch : 25.4 / i.pitch;
    var cands = THREADS.map(function (t) {
      return { t: t, d: Math.abs(t.od - i.od), pd: pitchMm ? Math.abs(t.pitch - pitchMm) / t.pitch : null };
    }).filter(function (c) { return c.d <= Math.max(1.5, i.od * 0.06); });
    if (pitchMm) cands = cands.filter(function (c) { return c.pd <= 0.025; });
    cands.sort(function (a, b) { return a.d - b.d; });
    return { pitchMm: pitchMm, list: cands.slice(0, 4) };
  }

  /* ===== KONVERSI ===== */
  var CONV = {
    tekanan: { base: 'bar', units: { bar: 1, psi: 1 / 14.5037738, MPa: 10, kPa: 0.01, 'kgf/cm²': 0.980665 } },
    gaya: { base: 'kN', units: { kN: 1, 'ton-f': G, kgf: G / 1000, N: 0.001 } },
    panjang: { base: 'mm', units: { mm: 1, inch: 25.4, cm: 10 } },
    torsi: { base: 'N·m', units: { 'N·m': 1, 'kgf·m': G, 'kgf·cm': G / 100, 'lbf·ft': 1.35581795 } }
  };
  function convert(group, unit, val) {
    var out = {};
    if (group === 'suhu') {
      var c = unit === '°C' ? val : (val - 32) * 5 / 9;
      out['°C'] = c; out['°F'] = c * 9 / 5 + 32; return out;
    }
    var g = CONV[group]; var base = val * g.units[unit];
    Object.keys(g.units).forEach(function (u) { out[u] = base / g.units[u]; });
    return out;
  }

  var api = { parseNum: parseNum, output: output, target: target, downtime: downtime, heater: heater, ssr: ssr,
    tonaseIMM: tonaseIMM, tonaseEBM: tonaseEBM, shot: shot, cooling: cooling, ulir: ulir,
    THREADS: THREADS, THREAD_INFO: THREAD_INFO, CONV: CONV, convert: convert, G: G };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.KT = api;
})(this);
